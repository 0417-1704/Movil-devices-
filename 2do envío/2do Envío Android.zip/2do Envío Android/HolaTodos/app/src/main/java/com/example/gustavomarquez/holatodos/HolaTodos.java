package com.example.gustavomarquez.holatodos;

/**
 * Created by Gustavo Márquez on 10/23/2025.
 */

import android.app.Activity;
import android.os.Bundle;

public class HolaTodos extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_layout);
    }
}
